@echo off
cd /d "%~dp0code"
if not exist .venv\Scripts\activate.bat (
  echo Run 2_SETUP_PYTHON.bat first. & pause & exit /b 1
)
call .venv\Scripts\activate.bat
python scripts\render_scan.py --out "%~dp0my_scan.png"
echo.
echo  Picture saved as my_scan.png next to this file.
pause
