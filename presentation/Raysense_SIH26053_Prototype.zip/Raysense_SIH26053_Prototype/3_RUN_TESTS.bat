@echo off
cd /d "%~dp0code"
if not exist .venv\Scripts\activate.bat (
  echo Run 2_SETUP_PYTHON.bat first. & pause & exit /b 1
)
call .venv\Scripts\activate.bat
python -m pytest -q
echo.
echo  Expected: 103 passed
pause
