@echo off
start "" "%~dp0DEMO\demo.html"
