@echo off
cd /d "%~dp0code"
echo ================================================
echo   Raysense - one-time setup
echo ================================================
where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo  ERROR: Python is not installed, or not on PATH.
  echo  Install it from https://www.python.org/downloads/
  echo  and TICK the box "Add python.exe to PATH".
  echo.
  pause & exit /b 1
)
python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -e ".[dev]"
echo.
echo  Setup finished. Now run 3_RUN_TESTS.bat
pause
